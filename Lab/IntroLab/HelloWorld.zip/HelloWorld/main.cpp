/* 
 * File:   HelloWorld.cpp
 * Author: Zachary Romero
 * Created on August 25, 2020, 2:53 PM
 */

#include <iostream>

int main ()
{
    std::cout << "Hello World!" << std::endl;
    return 0;
}